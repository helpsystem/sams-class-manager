SDS Scan - office scanner bridge for Sam's Driving School

1. Unzip this folder.
2. Double-click "Install SDS Scan.cmd".
   If Windows shows "Windows protected your PC": click "More info", then "Run anyway".
   If Windows asks about the firewall: click "Allow".
3. On the website (Student documents) press "Scan on the office scanner".

It only works for pages of samsdrivingschool.org, only on this computer, and stores nothing.
Settings and a log are in %APPDATA%\SDS-Scan.
