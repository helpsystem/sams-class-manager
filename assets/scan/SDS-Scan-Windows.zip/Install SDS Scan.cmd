@echo off
title SDS Scan - install
set "D=%LOCALAPPDATA%\SDS-Scan"
if not exist "%D%" mkdir "%D%"
taskkill /im SDS-Scan.exe /f >nul 2>&1
copy /y "%~dp0SDS-Scan.exe" "%D%\SDS-Scan.exe" >nul || (echo Could not copy the program. & pause & exit /b 1)
set "S=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\SDS-Scan.vbs"
> "%S%" echo CreateObject("WScript.Shell").Run """%D%\SDS-Scan.exe""", 0, False
wscript "%S%"
echo.
echo  SDS Scan is installed and running.
echo  It starts by itself whenever this computer starts.
echo  If Windows asks about the network (firewall), choose Allow - it is needed to find the scanner.
echo.
echo  Now go back to the website and press "Scan on the office scanner".
echo.
pause
