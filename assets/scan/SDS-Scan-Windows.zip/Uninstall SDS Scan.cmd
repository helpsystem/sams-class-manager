@echo off
taskkill /im SDS-Scan.exe /f >nul 2>&1
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\SDS-Scan.vbs" >nul 2>&1
rmdir /s /q "%LOCALAPPDATA%\SDS-Scan" >nul 2>&1
echo SDS Scan was removed.
pause
